from django import forms
from parking_app.models import Driver, Vehicle, Permit, Violation, Payment, ParkingSpot, Administrator, ParkingLot 

# IS 4460 Project Forms

class DriverForm(forms.ModelForm):
    class Meta:
        model = Driver
        fields = ['username', 'password', 'name', 'email', 'phoneNumber']


class VehicleForm(forms.ModelForm):
    class Meta:
        model = Vehicle
        fields = ['licensePlate', 'make', 'model', 'color', 'year']


class PermitForm(forms.ModelForm):
    driver = forms.ModelChoiceField(queryset=Driver.objects.all(), required=False)
    class Meta:
        model = Permit
        fields = ['permitType', 'issueDate', 'expirationDate', 'status', 'driver']


class ViolationForm(forms.ModelForm):
    class Meta:
        model = Violation
        fields = ['violationType', 'violationDate', 'fineAmount', 'status']


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['amount', 'paymentDate', 'paymentMethod']


class ParkingSpotForm(forms.ModelForm):
    class Meta:
        model = ParkingSpot
        fields = ['location', 'size', 'status']

class AdministratorForm(forms.ModelForm):
    class Meta:
        model = Administrator
        fields = '__all__'


class ParkingLotForm(forms.ModelForm):
    class Meta:
        model = ParkingLot
        fields = ['address', 'totalSpots', 'availableSpots']





