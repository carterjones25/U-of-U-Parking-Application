from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect, reverse
from django.views import View

from parking_app import admin
from .models import Driver, Vehicle, Permit, Violation, Payment, ParkingSpot, Administrator, ParkingLot
from .forms import DriverForm, VehicleForm, PermitForm, ViolationForm, PaymentForm, ParkingSpotForm, AdministratorForm, ParkingLotForm
from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import logout, authenticate, login

# IS 4460 Project VIEWS


# -------- LOGIN VIEWS --------

class LoginView(LoginView):
    template_name = 'parking_app/login.html'



# -------- LOGOUT VIEWS --------
def admin_logout(request):
    logout(request)
    return redirect('login')

def user_logout(request):
    logout(request)
    return redirect('login')


# -------- DRIVER VIEWS --------

# Driver creates an account
class Register(View):
    def get(self, request):
        driver = Driver()
        form = DriverForm(instance=Driver())
        return render(request=request,
                      template_name="parking_app/register.html",
                      context={"form": form,
                               "driver": driver
                               })
    
    def post(self, request):
        form = DriverForm(request.POST)
        if form.is_valid():
            driver = form.save()
            print("Driver registered successfully")
            return redirect('profile', driver_id=driver.id)
        else:
            print("Form errors:", form.errors)
            print("Driver registration failed")
            return render(request=request,
                          template_name="parking_app/register.html",
                          context={"form": form})
        
# Driver views their account
class DriverProfile(View):
    def get(self, request, driver_id=None):
        driver = Driver.objects.get(id=driver_id)
        return render(request=request,
                      template_name="parking_app/profile.html",
                      context={"driver": driver})
    
# Driver updates their account
class UpdateDriverProfile(View):
    def get(self, request, driver_id=None):
        driver = Driver.objects.get(id=driver_id)

        form = DriverForm(instance=driver)

        return render(request=request,
                      template_name="parking_app/update_profile.html",
                      context={"form": form,
                               "driver": driver
                               })
    
    def post(self, request, driver_id=None):
        if driver_id:
            driver = Driver.objects.get(id=driver_id)
        else:
            driver = Driver()
        
        form = DriverForm(request.POST, request.FILES, instance=driver)
        
        if form.is_valid():
            form = form.save()
            return redirect(reverse('profile', args=[driver.id]))
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/update_profile.html',
                      context={'driver': driver,
                               'form': form})
    

# --------- LOGIN VIEWS --------
class Login(View):
    def get(self, request):
        return render(request=request,
                      template_name="parking_app/login.html",
                      context={})
    
    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        driver = Driver.objects.filter(username=username, password=password).first()
        if driver:
            return redirect('profile', driver_id=driver.id)
    

        admin = authenticate(request, username=username, password=password)
        if admin:
            login(request, admin)
            next_url = request.GET.get('next', None)
            if next_url:
                return HttpResponseRedirect(next_url)
            return redirect('admin_profile', admin_id=admin.id)
        

        
        return render(request=request,
                          template_name="parking_app/login.html",
                          context={"error": "Invalid credentials"})
        
class AdminProfile(LoginRequiredMixin, View):
    def get(self, request, admin_id=None):
        if request.user.is_authenticated:
            try:
                admin = Administrator.objects.get(id=admin_id)
                if admin.username == request.user.username:
                    return render(request=request,
                                  template_name="parking_app/admin_profile.html",
                                  context={"admin": admin})
            except Administrator.DoesNotExist:
                pass
        
        return render(request=request,
                      template_name="parking_app/login.html",
                      context={"error": "You do not have permission to view this page"})

        
# Delete profile
class DriverDelete(View):
    def post(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        driver.delete()
        return redirect('login')
    

# -------- VEHICLE VIEWS --------


# Add a vehicle
class VehicleAdd(View):
    def get(self, request, driver_id):
        driver = get_object_or_404(Driver, id=driver_id)
        vehicle = Vehicle()
        form = VehicleForm(instance=Vehicle())
        return render(request=request,
                      template_name="parking_app/vehicle_add.html",
                      context={"form": form,
                               "vehicle": vehicle,
                               "driver": driver
                               })
    
    def post(self, request, driver_id):
        driver = get_object_or_404(Driver, id=driver_id)
        form = VehicleForm(request.POST)
        if form.is_valid():
            vehicle = form.save(commit=False)
            vehicle.driver = driver
            vehicle.save()
            print("Vehicle added successfully")
            return redirect('vehicle_list', driver_id=driver_id)
        else:
            print("Form errors:", form.errors)
            print("Vehicle addition failed")
            return render(request=request,
                          template_name="parking_app/vehicle_add.html",
                          context={"form": form,
                                   "driver": driver,})

# List vehicles
class VehicleList(View):
    def get(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        vehicles = Vehicle.objects.filter(driver=driver)
        return render(request=request,
                      template_name="parking_app/vehicle_list.html",
                      context={"vehicles": vehicles,
                               "driver": driver
                               })
    
# Edit a vehicle
class VehicleEdit(View):
    def get(self, request, driver_id, vehicle_id):
        driver = Driver.objects.get(id=driver_id)
        vehicle = Vehicle.objects.get(id=vehicle_id)
        form = VehicleForm(instance=vehicle)
        return render(request=request,
                      template_name="parking_app/vehicle_edit.html",
                      context={"form": form,
                               "vehicle": vehicle,
                               "driver": driver
                               })
    
    def post(self, request, driver_id, vehicle_id):
        driver = Driver.objects.get(id=driver_id)
        vehicle = Vehicle.objects.get(id=vehicle_id)
        form = VehicleForm(request.POST, instance=vehicle)
        
        if form.is_valid():
            form.save()
            return redirect('vehicle_list', driver_id=driver.id)
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/vehicle_edit.html',
                      context={'driver': driver,
                               'form': form})
    
# Delete a vehicle
class VehicleDelete(View):
    def post(self, request, driver_id, vehicle_id):
        vehicle = Vehicle.objects.get(id=vehicle_id)
        vehicle.delete()
        return redirect('vehicle_list', driver_id=driver_id)
    

# ADMIN VehicleAdd
class VehicleAddAdmin(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = VehicleForm(instance=Vehicle())
        drivers = Driver.objects.all()
        return render(request=request,
                      template_name="parking_app/admin_vehicle_add.html",
                      context={"form": form,
                               "admin": admin,
                                 "drivers": drivers
                               })
    
    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = VehicleForm(request.POST)
        
        if form.is_valid():
            vehicle = form.save(commit=False)
            driver_id = request.POST.get('driver')
            if driver_id:
                vehicle.driver = get_object_or_404(Driver, id=driver_id)
            vehicle.save()
            print("Vehicle added successfully")
            return redirect('vehicle_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/admin_vehicle_add.html',
                      context={'admin': admin,
                               'form': form})



# ADMIN VEHICLE MANAGE
class VehicleManage(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        vehicles = Vehicle.objects.all()
        form = VehicleForm()
        return render(request=request,
                      template_name="parking_app/vehicle_manage.html",
                      context={"vehicles": vehicles,
                               "admin": admin,
                                 "form": form
                               })
    
    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = VehicleForm(request.POST)
        
        if form.is_valid():
            vehicle = form.save(commit=False)
            vehicle.driver = None
            vehicle.save()
            print("Vehicle added successfully")
            return redirect('vehicle_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors) 
        vehicles = Vehicle.objects.all()
        return render(request=request,
                      template_name='parking_app/vehicle_manage.html',
                      context={'admin': admin,
                               'form': form,
                               'vehicles': vehicles})


# -------- PERMIT VIEWS --------
        
# List permits
class PermitList(View):
    def get(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        permits = Permit.objects.filter(driver=driver, is_active=True)
        return render(request=request,
                      template_name="parking_app/permit_list.html",
                      context={"permits": permits,
                               "driver": driver
                               })
    
# Permit report
class PermitReport(View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        permit_type = request.GET.get('permitType', None)
        permits = Permit.objects.filter(is_active=True)

        if permit_type:
            permits = permits.filter(permitType=permit_type)

        return render(request=request,
                      template_name="parking_app/permit_report.html",
                      context={"permits": permits,
                               "permit_type": permit_type,
                                 "admin": admin
                               })

    
# Remove a permit
class PermitRemove(View):
    def post(self, request, driver_id, permit_id):
        permit = Permit.objects.get(id=permit_id)
        permit.is_active = False
        permit.save()
        return redirect('permit_list', driver_id=driver_id)
    
# Delete a permit
class PermitDelete(LoginRequiredMixin, View):
    def post(self, request, admin_id, permit_id):
        permit = Permit.objects.get(id=permit_id)
        permit.delete()
        return redirect('permit_manage', admin_id=admin_id)
    
# Apply for a permit
class PermitApply(View):
    def get(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        permits = Permit.objects.all()
        return render(request=request,
                      template_name="parking_app/permit_apply.html",
                      context={"permits": permits,
                               "driver": driver
                               })
    
    def post(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        form = PermitForm(request.POST)
        if form.is_valid():
            permit = form.save(commit=False)
            permit.driver = driver
            permit.save()
            print("Permit applied successfully")
            return redirect('permit_list', driver_id=driver.id)
        else:
            print("Form errors:", form.errors)
            print("Permit application failed")
            return render(request=request,
                          template_name="parking_app/permit_apply.html",
                          context={"form": form,
                                   "driver": driver})
        

# PAYMENT FOR PERMIT VIEW
class PaymentView(View):
    def get(self, request, driver_id, permit_id):
        driver = Driver.objects.get(id=driver_id)
        permit = Permit.objects.get(id=permit_id)
    
        
        form = PaymentForm()
        return render(request, 'parking_app/payment.html', {
            'form': form,
            'driver': driver,
            'permit': permit,
        })

    def post(self, request, driver_id, permit_id):
        driver = Driver.objects.get(id=driver_id)
        permit = Permit.objects.get(id=permit_id)
        
        
        form = PaymentForm(request.POST)
        
        if form.is_valid():
            
            payment = form.save(commit=False)  
            payment.driver = driver
            payment.permit = permit
            payment.save() 

            permit.driver = driver
            permit.is_active = True
            permit.save()  
            
            print("Payment processed successfully")
            return redirect('permit_list', driver_id=driver.id)  

        return render(request, 'parking_app/payment.html', {
            'form': form,
            'driver': driver,
            'permit': permit, 
        })
    
# Manage permits
class PermitManage(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        permits = Permit.objects.all()
        return render(request=request,
                      template_name="parking_app/permit_manage.html",
                      context={"permits": permits,
                               "admin": admin
                               })
    
# Edit permit
class PermitEdit(LoginRequiredMixin, View):
    def get(self, request, admin_id, permit_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        permit = Permit.objects.get(id=permit_id)
        form = PermitForm(instance=permit)
        drivers = Driver.objects.all()
        return render(request=request,
                      template_name="parking_app/permit_edit.html",
                      context={"form": form,
                               "permit": permit,
                               "admin": admin,
                               "drivers": drivers
                               })
    
    def post(self, request, admin_id, permit_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        permit = Permit.objects.get(id=permit_id)
        form = PermitForm(request.POST, instance=permit)
        
        if form.is_valid():
            form.save()
            return redirect('permit_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/permit_edit.html',
                      context={'admin': admin,
                               'form': form,
                               'permit': permit})
    

# Payment list
class PaymentList(View):
    def get(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        payments = Payment.objects.filter(driver=driver)
        return render(request=request,
                      template_name="parking_app/payment_list.html",
                      context={"payments": payments,
                               "driver": driver
                               })

        
# Add a permit

def can_add_permit(request):
    return request.user.groups.filter(name='PermitAdd').exists()

class PermitAdd(LoginRequiredMixin,View):
    def get(self, request, admin_id):
        print("GET request received")
        admin = get_object_or_404(Administrator, id=admin_id)
        form = PermitForm()
        return render(request=request,
                      template_name="parking_app/permit_add.html",
                      context={"form":form, "admin": admin})
    
    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)

        if can_add_permit(request):
            print("POST data:", request.POST)
            form = PermitForm(request.POST)

            if form.is_valid():
                permit = form.save(commit=False)
                permit.driver = None
                permit.is_active = True

                try:
                    permit.save()
                    print("Permit added successfully")
                except Exception as e:
                    print("Error saving permit:", e)
                
               
                return redirect('permit_manage', admin_id=admin.id)
            else:
                print("Form errors:", form.errors)
                return render(request=request,
                              template_name="parking_app/permit_add.html",
                              context={"form": form, "admin": admin})
        else:
            return render(request=request,
                          template_name="parking_app/permit_add.html",
                          context={"error": "You do not have permission to add a permit",
                          "admin": admin})
        
# List drivers
class DriverList(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        drivers = Driver.objects.all()
        return render(request=request,
                      template_name="parking_app/driver_list.html",
                      context={"drivers": drivers,
                               "admin": admin
                               })
    

# -------- VIOLATION VIEWS --------

# Violation report
class ViolationReport(View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        violation_type = request.GET.get('violationType', None)
        violations = Violation.objects.filter(is_active=True)

        if violation_type:
            violations = violations.filter(violationType=violation_type)

        return render(request=request,
                      template_name="parking_app/violation_report.html",
                      context={"violations": violations,
                               "violation_type": violation_type,
                                 "admin": admin
                               })

def can_add_violation(request):
    return request.user.groups.filter(name='ViolationAdd').exists()


# Add a violation
class ViolationAdd(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        driver = Driver.objects.all()
        form = ViolationForm()
        return render(request=request,
                        template_name="parking_app/violation_add.html",
                        context={"form": form,
                                 "admin": admin,
                                 "drivers": driver
                                 })
    
    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)

        if can_add_violation(request):
            print("POST data:", request.POST)
            form = ViolationForm(request.POST)

            if form.is_valid():
                violation = form.save(commit=False)
                driver_id = request.POST.get('driver_id')
                if driver_id:
                    violation.driver = get_object_or_404(Driver, id=driver_id)
                violation.save()
                print("Violation added successfully")
                return redirect('violation_manage', admin_id=admin.id)
            else:
                print("Form errors:", form.errors)
                return render(request=request,
                              template_name="parking_app/violation_add.html",
                              context={"form": form, "admin": admin})
        else:
            return render(request=request,
                          template_name="parking_app/violation_add.html",
                          context={"error": "You do not have permission to add a violation",
                          "admin": admin})

        

# Manage violations
class ViolationManage(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        violations = Violation.objects.all()
        return render(request=request,
                      template_name="parking_app/violation_manage.html",
                      context={"violations": violations,
                               "admin": admin
                               })
    
# Edit a violation
class ViolationEdit(LoginRequiredMixin, View):
    def get(self, request, admin_id, violation_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        violation = Violation.objects.get(id=violation_id)
        form = ViolationForm(instance=violation)
        drivers = Driver.objects.all()
        return render(request=request,
                      template_name="parking_app/violation_edit.html",
                      context={"form": form,
                               "violation": violation,
                               "admin": admin,
                               "drivers": drivers
                               })
    
    def post(self, request, admin_id, violation_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        violation = Violation.objects.get(id=violation_id)
        form = ViolationForm(request.POST, instance=violation)
        drivers = Driver.objects.all()
        if form.is_valid():
            form.save()
            return redirect('violation_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors)
        return render(request=request,
                      template_name='parking_app/violation_edit.html',
                      context={'admin': admin,
                               'form': form,
                               'violation': violation})
    
# Delete a violation
class ViolationDelete(LoginRequiredMixin, View):
    def post(self, request, admin_id, violation_id):
        violation = Violation.objects.get(id=violation_id)
        violation.delete()
        return redirect('violation_manage', admin_id=admin_id)
    
# List violations
class ViolationList(View):
    def get(self, request, driver_id):
        driver = Driver.objects.get(id=driver_id)
        violations = Violation.objects.filter(driver=driver, is_active=True)
        return render(request=request,
                      template_name="parking_app/violation_list.html",
                      context={"violations": violations,
                               "driver": driver
                               })
    

# PAYMENT FOR VIOLATION VIEW
class PaymentViolationView(View):
    def get(self, request, driver_id, violation_id):
        driver = Driver.objects.get(id=driver_id)
        violation = Violation.objects.get(id=violation_id)
        
        form = PaymentForm()
        return render(request, 'parking_app/payment_violation.html', {
            'form': form,
            'driver': driver,
            'violation': violation,
        })

    def post(self, request, driver_id, violation_id):
        driver = Driver.objects.get(id=driver_id)
        violation = Violation.objects.get(id=violation_id)
        
        form = PaymentForm(request.POST)
        
        if form.is_valid():
            payment = form.save(commit=False)  
            payment.driver = driver
            payment.violation = violation 
            payment.permit = None
            violation.is_active = False
            payment.save() 

           
            violation.status = "Paid"  
            violation.save()  
            
            print("Payment processed successfully")
            return redirect('violation_list', driver_id=driver.id)  

        return render(request, 'parking_app/payment_violation.html', {
            'form': form,
            'driver': driver,
            'violation': violation, 
        })
    
# -------- PARKING SPOT VIEWS --------

def can_add_parking_spot(request):
    return request.user.groups.filter(name='ParkingAdd').exists()

# Add a parking spot
class ParkingSpotAdd(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = ParkingSpotForm()
        return render(request=request,
                      template_name="parking_app/spot_add.html",
                      context={"form": form,
                               "admin": admin})

    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)  
        if can_add_parking_spot(request):
            form = ParkingSpotForm(request.POST)

            if form.is_valid():
                parking_spot = form.save(commit=False)
                parking_spot.save()
                print("Parking spot added successfully")
                return redirect('spot_manage', admin_id=admin.id)  
            else:
                print("Form errors:", form.errors)
                return render(request=request,
                              template_name="parking_app/spot_add.html",
                              context={"form": form, "admin": admin})
        else:
            return render(request=request,
                          template_name="parking_app/spot_add.html",
                          context={"error": "You do not have permission to add a parking spot",
                                    "admin": admin})

# Manage parking spots
class ParkingSpotManage(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_spots = ParkingSpot.objects.all()
        return render(request=request,
                      template_name="parking_app/spot_manage.html",
                      context={"parking_spots": parking_spots,
                               "admin": admin})

# Edit parking spots
class ParkingSpotEdit(LoginRequiredMixin, View):
    def get(self, request, admin_id, spot_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_spot = get_object_or_404(ParkingSpot, id=spot_id)
        form = ParkingSpotForm(instance=parking_spot)
        return render(request=request,
                      template_name="parking_app/spot_edit.html",
                      context={"form": form,
                               "parking_spot": parking_spot,
                               "admin": admin})

    def post(self, request, admin_id, spot_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_spot = get_object_or_404(ParkingSpot, id=spot_id)
        form = ParkingSpotForm(request.POST, instance=parking_spot)
        if form.is_valid():
            form.save()
            return redirect('spot_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors)
        return render(request=request,
                      template_name='parking_app/spot_edit.html',
                      context={'admin': admin,
                               'form': form,
                               'parking_spot': parking_spot})

# Delete parking spots
class ParkingSpotDelete(LoginRequiredMixin, View):
    def post(self, request, admin_id, spot_id):
        parking_spot = get_object_or_404(ParkingSpot, id=spot_id)
        parking_spot.delete()
        return redirect('spot_manage', admin_id=admin_id)
    

    
# -------- PARKING LOT VIEWS --------

# Manage parking lots
class ParkingLotManage(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_lots = ParkingLot.objects.all()
        return render(request=request,
                      template_name="parking_app/lot_manage.html",
                      context={"parking_lots": parking_lots,
                               "admin": admin})
    
# Add a parking lot
class ParkingLotAdd(LoginRequiredMixin, View):
    def get(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = ParkingLotForm()
        return render(request=request,
                      template_name="parking_app/lot_add.html",
                      context={"form": form,
                               "admin": admin})
    
    def post(self, request, admin_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        form = ParkingLotForm(request.POST)
        
        if form.is_valid():
            parking_lot = form.save(commit=False)
            parking_lot.save()
            print("Parking lot added successfully")
            return redirect('lot_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/lot_add.html',
                      context={'admin': admin,
                               'form': form})
    
# Edit parking lots
class ParkingLotEdit(LoginRequiredMixin, View):
    def get(self, request, admin_id, lot_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_lot = get_object_or_404(ParkingLot, id=lot_id)
        form = ParkingLotForm(instance=parking_lot)
        return render(request=request,
                      template_name="parking_app/lot_edit.html",
                      context={"form": form,
                               "parking_lot": parking_lot,
                               "admin": admin})
    
    def post(self, request, admin_id, lot_id):
        admin = get_object_or_404(Administrator, id=admin_id)
        parking_lot = get_object_or_404(ParkingLot, id=lot_id)
        form = ParkingLotForm(request.POST, instance=parking_lot)
        
        if form.is_valid():
            form.save()
            return redirect('lot_manage', admin_id=admin.id)
        else:
            print("Form errors:", form.errors) 
        return render(request=request,
                      template_name='parking_app/lot_edit.html',
                      context={'admin': admin,
                               'form': form,
                               'parking_lot': parking_lot})
    

# Delete parking lots
class ParkingLotDelete(LoginRequiredMixin, View):
    def post(self, request, admin_id, lot_id):
        parking_lot = get_object_or_404(ParkingLot, id=lot_id)
        parking_lot.delete()
        return redirect('lot_manage', admin_id=admin_id)


