from django.db import models

class Administrator(models.Model):
    username = models.CharField(max_length=100, null=False)
    password = models.CharField(max_length=100, null=False)
    name = models.CharField(max_length=100, null=False)
    email = models.CharField(max_length=100, null=False)
    phoneNumber = models.CharField(max_length=15, null=False)
    role = models.CharField(max_length=50, null=False)


class ParkingLot(models.Model):
    name = models.CharField(max_length=100, null=False)
    address = models.CharField(max_length=255, null=False)
    totalSpots = models.CharField(max_length=500, null=False)
    availableSpots = models.CharField(max_length=500, null=False)


class ParkingSpot(models.Model):
    location = models.CharField(max_length=100, null=False)
    size = models.CharField(max_length=50, null=False)
    status = models.CharField(max_length=50, null=False)


class Driver(models.Model):
    username = models.CharField(max_length=100, null=False)
    password = models.CharField(max_length=100, null=False)
    name = models.CharField(max_length=100, null=False)
    email = models.CharField(max_length=100, null=False)
    phoneNumber = models.CharField(max_length=15, null=False)
    accountCreated = models.DateTimeField(auto_now_add=True)


class Vehicle(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
    licensePlate = models.CharField(max_length=20, null=False)
    make = models.CharField(max_length=50, null=False)
    model = models.CharField(max_length=50, null=False)
    color = models.CharField(max_length=50, null=True)
    year = models.CharField(max_length=4, null=True)


class Permit(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE, null=True)
    is_active = models.BooleanField(default=True)
    permitType = models.CharField(max_length=50, null=False)
    issueDate = models.DateField(null=False)
    expirationDate = models.DateField(null=False)
    status = models.CharField(max_length=50, null=False)


class Violation(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    violationType = models.CharField(max_length=50, null=False)
    violationDate = models.DateField(null=False)
    fineAmount = models.CharField(max_length=50, null=False)
    status = models.CharField(max_length=50, null=False)


class Payment(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
    permit = models.ForeignKey(Permit, on_delete=models.CASCADE, null=True)
    violation = models.ForeignKey(Violation, on_delete=models.CASCADE, null=True)
    amount = models.CharField(max_length=50, null=False)
    paymentDate = models.CharField(max_length=50, null=False)
    paymentMethod = models.CharField(max_length=50, null=False)
