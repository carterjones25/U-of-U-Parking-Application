from django.contrib import admin

from .models import Administrator

@admin.register(Administrator)
class AdministratorAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'phoneNumber', 'role')
    search_fields = ('username', 'name', 'email')